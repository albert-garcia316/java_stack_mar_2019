package object_master;

public class Tester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Human a = new Human();
		Human b = new Human();
		System.out.println(a.strength);
		a.attack(b);
		b.getHealth();
	}

}
